import numpy as np
import matplotlib.pyplot as plt

theta_deg = np.linspace(0, 360, 721)
theta = np.deg2rad(theta_deg)

# CHSH: S = E(a,b) - E(a,b') + E(a',b) + E(a',b'), E = -cos(Δθ)
S = np.abs(-np.cos(theta) + np.cos(theta + np.pi/2)
           - np.cos(np.pi/2 - theta) - np.cos(theta))

classical_bound = 2
quantum_max = 2 * np.sqrt(2)

plt.figure(figsize=(8, 5))
plt.plot(theta_deg, S, label='Quantum $S(\\theta)$')
plt.axhline(classical_bound, color='r', linestyle='--', label='CHSH bound: 2')
plt.axhline(quantum_max, color='g', linestyle=':', label='Tsirelson bound: $2\\sqrt{2}$')
plt.xlabel('Relative angle $\\theta$ (degrees)')
plt.ylabel('$S$')
plt.title('Quantum violation of the CHSH inequality')
plt.legend()
plt.grid(alpha=0.3)
plt.show()

print(f"Maximum S = {S.max():.4f} at θ = {theta_deg[S.argmax()]:.1f}°")